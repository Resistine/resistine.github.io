# Help Plugin

Comprehensive documentation for the Resistine Desktop application.

## Features
- Markdown-based manual viewer.
- Navigation history (Back/Home).
- Embedded link support for inter-document navigation.
- Platform-specific help topics.

## Usage
Browse the built-in documentation to learn more about Resistine's features and configuration.
