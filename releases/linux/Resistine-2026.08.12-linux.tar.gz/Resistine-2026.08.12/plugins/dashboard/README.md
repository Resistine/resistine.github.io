# Dashboard Plugin

The primary control surface for the Resistine application.

## Features
- Global protection status overview.
- Quick-access grid to all installed plugins.
- Modern, theme-aware interface.
- Real-time security alerts.

## Usage
Click on any plugin card to navigate to its specific feature set.
