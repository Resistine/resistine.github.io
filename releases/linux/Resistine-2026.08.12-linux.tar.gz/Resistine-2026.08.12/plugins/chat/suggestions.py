"""Suggestion prompts for the chat welcome screen (framework-free)."""

# Pool of suggestion prompts shown on the welcome screen.
# 4 are picked at random each time the chat is opened.
SUGGESTION_POOL = [
    "Explain what a zero-day exploit is",
    "How do I harden my Linux server?",
    "Analyze a suspicious network log",
    "What are common phishing indicators?",
    "How does a man-in-the-middle attack work?",
    "What is the MITRE ATT&CK framework?",
    "Explain the difference between IDS and IPS",
    "How do I set up a firewall with iptables?",
    "What are best practices for password security?",
    "How do I detect lateral movement in a network?",
    "Explain DNS tunneling and how to detect it",
    "What is ransomware and how do I prevent it?",
]
