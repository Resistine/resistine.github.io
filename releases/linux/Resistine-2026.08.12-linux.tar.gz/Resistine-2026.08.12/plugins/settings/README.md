# Settings Plugin

Global configuration manager for the Resistine environment.

## Features
- **Profile Management**: View your authenticated email account.
- **Secrets Management**: Securely store and encrypt API keys (e.g., OpenAI).
- **Appearance**: Toggle between Light, Dark, and System themes.
- **Privacy**: All settings are stored locally and encrypted using the system keyring.

## Usage
Access this plugin to customize your experience and provide necessary credentials for other plugins like Chat.
