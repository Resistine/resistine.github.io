# Login Plugin

Secure authentication gateway for the Resistine platform.

## Features
- Email-based OTP authentication.
- Automatic VPN key provisioning upon successful login.
- Integration with the Resistine identity provider.
- Secure token management.

## Security
This plugin handles sensitive authentication flows and is required for full access to the Resistine security network.
