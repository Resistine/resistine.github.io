# VPN Plugin

Advanced WireGuard-based VPN management.

## Features
- **Cross-Platform**: Intelligent VPN controls for Windows, Linux, and macOS.
- **Status Monitoring**: Real-time connection state tracking.
- **One-Click Connect**: Simplified tunnel management.
- **Secure Provisioning**: Keys are automatically managed via the Login plugin.

## Technical Details
This plugin acts as a frontend for the platform's WireGuard implementation, providing a unified security experience across different operating systems.
