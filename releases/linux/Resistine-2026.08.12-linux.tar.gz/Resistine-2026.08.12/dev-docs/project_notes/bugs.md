# Known Bugs & Past Fixes

Record bugs with root causes and solutions so they don't get re-investigated.

## Template

### [Date] — Bug Title
- **Symptom:** What was observed?
- **Root Cause:** Why did it happen?
- **Fix:** What was changed?
- **Files:** Which files were modified?

---
