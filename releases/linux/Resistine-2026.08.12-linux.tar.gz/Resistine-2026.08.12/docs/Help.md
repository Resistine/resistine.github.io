# Resistine Help

Welcome to **Resistine** — AI EndPoint Detection and Response (AI EDR) for
Windows, macOS, and Linux. This page is your starting point; use the dropdown
above to browse the other help topics.

## Getting Started

Sign in from the **Login** screen, then use the sidebar on the left to move
between features. The **Dashboard** gives you a one-glance view of your
protection status — start there.

## Features

Each item in the sidebar is a feature:

- **Dashboard** — See your protection status at a glance.
- **Chat** — Ask the Resistine AI assistant for help and guidance.
- **VPN** — Connect to a secure WireGuard VPN and manage your configurations.
- **Endpoint** — Install and manage the SIEM agent that monitors your device.
- **Antivirus** — Scan, quarantine, and protect against malware.
- **Store** — Browse and install additional plugins.
- **Help** — This documentation.
- **Settings** — Manage your account and application preferences.

Some features (such as Chat and the Endpoint agent) require an active VPN
connection. If a feature seems unavailable, connect the VPN first.

## Troubleshooting

- **A feature won't load** — Make sure you're signed in and, where required,
  connected to the VPN. Restarting the app clears most transient issues.
- **VPN won't connect** — Check your internet connection and confirm your
  configuration under the VPN tab.
- **Something looks wrong** — Resistine updates itself automatically. See
  **Releases** (in the dropdown above) for version and update details.

## More Information

- **Releases** — Version history, system requirements, and how updates work.
- **LICENSE** — The GNU General Public License v2 (or later) that Resistine is
  distributed under.
- **LICENSE-3rd-Party** — The full third-party software bill of materials
  (SBOM): every bundled component with its version and license.

## About

Resistine AI EndPoint Detection and Response (AI EDR)
for Windows, macOS, and Linux desktops.

Copyright (C) 2025 Resistine

This program is free software under the terms of the GNU General Public
License v2 or later. Resistine comes with ABSOLUTELY NO WARRANTY.

See the **LICENSE** entry in the dropdown above for full details.
