"""Re-export windows_vpn_service from its canonical location for test imports."""

from plugins.vpn.wireguard.windows_vpn_service import *  # noqa: F401,F403
